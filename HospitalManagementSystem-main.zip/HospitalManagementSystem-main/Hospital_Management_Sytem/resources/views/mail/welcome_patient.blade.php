<!DOCTYPE html>
<html>
<head>
    <title>Welcome New User</title>
</head>
<body>
<h1>Welcome, {{ $name }}!</h1>
<p>Thank you for joining us.</p>
<p>You Can Login Here <a href="{{$url}}">{{$url}}</a></p>
<p>Your account has been successfully created, and you can now start scheduling your appointments with the doctors from
    our hospital.</p>
<p>Best Regards,<br>SAKURA Team</p>
</body>
</html>
